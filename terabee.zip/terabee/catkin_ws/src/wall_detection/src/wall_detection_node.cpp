#include "ros/ros.h"
#include "std_msgs/String.h"
#include "sensor_msgs/Range.h"
#include "math.h"
#include <iostream>

float measure;

void controlla_misura(float mis)
{
    if( mis <0.5 ){
        std::cout<<"MURO"<<std::endl;
    }
    else{
        std::cout<<"NO MURO="<<float(mis)<<std::endl;     
    }       
}

void terabeeCallback(const sensor_msgs::Range::ConstPtr& msg)
{
    // ROS_INFO("I heard: [%f]", msg->range);
    measure=msg->range;
    controlla_misura(measure);
}

int main(int argc, char **argv)
{

    ros::init(argc, argv, "wall_detection_node");
    ros::NodeHandle n;
    ros::Rate rate(10);
    ros::Subscriber sub = n.subscribe("/teraranger_evo", 1000, terabeeCallback);

    while (ros::ok()){
        ros::spinOnce();
        rate.sleep();
    }

return 0;
}